const express = require("express");
const app = express();
const mysql = require("mysql");
const mongoose = require("mongoose");
const qnaRouter = require("./routers/qna");

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, DELETE, PATCH, PUT, OPTIONS"
  );
  next();
});

// mysql
var db = mysql.createConnection({
  host: "127.0.0.1", // ip address of server running mysql
  user: "itcpa", // user name to your mysql database
  password: "1234", // corresponding password
  database: "itcpa",
});

db.connect(function (err) {
  if (err) throw err;
  console.log("mysql Connected");
});

// mongodb
const mongoDbURL =
  "mongodb+srv://1234:1234@cluster0.yz15b.mongodb.net/qna?retryWrites=true&w=majority";
mongoose
  .connect(mongoDbURL)
  .then(() => console.log("mongodb connected"))
  .catch(() => console.log("mongodb connection failed"));

app.use(express.json());
app.use("/qna", qnaRouter);

app.get("/students", (req, res) => {
  let sql = "SELECT * FROM student";

  db.query(sql, (err, students) => {
    if (err) throw err;
    res.status(200).json(students);
  });  
});

module.exports = app;
